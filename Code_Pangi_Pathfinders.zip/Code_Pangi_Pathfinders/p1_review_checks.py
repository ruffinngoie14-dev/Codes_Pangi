"""Additional analyses requested in the internal review of Paper 1:
(1) small-sample cut-off for MCD distances by simulation; (2) dependence of samples within prospects:
prospect-level and cluster-bootstrap Spearman; (3) value below detection limit (J0907, 3 ppb < 5 ppb)."""
import json
import numpy as np
from scipy import stats
from sklearn.covariance import MinCovDet
from data import load, to_ppm

rng = np.random.default_rng(20261028)
df = load()
X = to_ppm(df)
out = {}

# (1) simulated 97.5% quantile of MCD squared distances for n=20, p=5 under multivariate normality
n, p = 20, 5
q = []
mx = []
for s in range(int(__import__("os").environ.get("NSIM","2000"))):
    Z = rng.standard_normal((n, p))
    d2 = MinCovDet(random_state=s).fit(Z).mahalanobis(Z)
    q.extend(d2.tolist())
    mx.append(d2.max())
q = np.array(q)
out["mcd_sim_q975_pointwise"] = float(np.quantile(q, 0.975))
out["mcd_sim_q95_max"] = float(np.quantile(mx, 0.95))
out["chi2_975"] = float(stats.chi2.ppf(0.975, p))
P = np.load("results/p1_pca.npy", allow_pickle=True).item()
d2 = P["d2"]
out["flag_sim_pointwise"] = list(df.id[d2 > out["mcd_sim_q975_pointwise"]])
out["flag_sim_max"] = list(df.id[d2 > out["mcd_sim_q95_max"]])
out["d2_sorted"] = sorted(zip(df.id, np.round(d2, 1)), key=lambda t: -t[1])[:9]

# (2) dependence within prospects
au, as_, cu = X.Au.values, X.As.values, X.Cu.values
med = df.groupby("prospect")[["Au", "As", "Cu"]].median()
out["prospect_median_rs_As"] = stats.spearmanr(med.Au, med.As)[0]
out["prospect_median_rs_Cu"] = stats.spearmanr(med.Au, med.Cu)[0]
groups = [np.where(df.prospect.values == g)[0] for g in df.prospect.unique()]
bs_as, bs_cu = [], []
for b in range(10000):
    pick = rng.integers(0, len(groups), len(groups))
    idx = np.concatenate([groups[i] for i in pick])
    if np.ptp(au[idx]) == 0:
        continue
    bs_as.append(stats.spearmanr(au[idx], as_[idx])[0])
    bs_cu.append(stats.spearmanr(au[idx], cu[idx])[0])
out["cluster_boot_rs_As_ci"] = list(np.nanpercentile(bs_as, [2.5, 97.5]))
out["cluster_boot_rs_Cu_ci"] = list(np.nanpercentile(bs_cu, [2.5, 97.5]))
# within-prospect permutation test: permute As within prospects (keeps between-prospect structure)
obs = stats.spearmanr(au, as_)[0]
cnt = 0
NP = 10000
for b in range(NP):
    a2 = as_.copy()
    for g in groups:
        a2[g] = rng.permutation(a2[g])
    cnt += stats.spearmanr(au, a2)[0] >= obs
out["within_perm_p_As"] = (cnt + 1) / (NP + 1)
# pooled within-prospect rank correlation (ranks within prospects, n>=3)
r_au, r_as, r_cu = [], [], []
for g in groups:
    if len(g) >= 3:
        r_au += list(stats.rankdata(au[g]) - (len(g) + 1) / 2)
        r_as += list(stats.rankdata(as_[g]) - (len(g) + 1) / 2)
        r_cu += list(stats.rankdata(cu[g]) - (len(g) + 1) / 2)
out["within_prospect_rank_r_As"] = float(np.corrcoef(r_au, r_as)[0, 1])
out["within_prospect_rank_r_Cu"] = float(np.corrcoef(r_au, r_cu)[0, 1])

# (3) J0907 below DL: substitute 2/3 DL = 3.33 ppb (already ~3 ppb) and DL/2 = 2.5 ppb
for sub in [0.0025, 0.00333, 0.005]:
    a = au.copy()
    a[df.id.values == "J0907"] = sub
    out[f"rs_As_J0907_{sub}"] = stats.spearmanr(a, as_)[0]
    la = np.log(a)
    out[f"rhop_As_J0907_{sub}"] = 1 - np.var(la - np.log(as_), ddof=1) / (np.var(la, ddof=1) + np.var(np.log(as_), ddof=1))
json.dump(out, open("results/p1_review_checks.json", "w"), indent=1, default=str)
print(json.dumps(out, indent=1, default=str))

# (4) full table of dependence-aware measures for the four elements
tab = {}
for e in ["As", "Cu", "Fe", "Zn"]:
    x = X[e].values
    bs = []
    for b in range(10000):
        pick = rng.integers(0, len(groups), len(groups))
        idx = np.concatenate([groups[i] for i in pick])
        if np.ptp(au[idx]) == 0 or np.ptp(x[idx]) == 0:
            continue
        bs.append(stats.spearmanr(au[idx], x[idx])[0])
    obs = stats.spearmanr(au, x)[0]
    cnt = 0
    for b in range(5000):
        x2 = x.copy()
        for g in groups:
            x2[g] = rng.permutation(x2[g])
        cnt += abs(stats.spearmanr(au, x2)[0]) >= abs(obs)
    ra, rx = [], []
    for g in groups:
        if len(g) >= 3:
            ra += list(stats.rankdata(au[g]) - (len(g) + 1) / 2)
            rx += list(stats.rankdata(x[g]) - (len(g) + 1) / 2)
    tab[e] = dict(cluster_ci=list(np.round(np.nanpercentile(bs, [2.5, 97.5]), 3)),
                  perm_within_p_two_sided=round((cnt + 1) / 5001, 4),
                  within_r=round(float(np.corrcoef(ra, rx)[0, 1]), 3),
                  prospect_median_rs=round(stats.spearmanr(med.Au, df.groupby("prospect")[e].median())[0], 3))
print(json.dumps(tab, indent=1))
json.dump(dict(out, table=tab), open("results/p1_review_checks.json", "w"), indent=1, default=str)
