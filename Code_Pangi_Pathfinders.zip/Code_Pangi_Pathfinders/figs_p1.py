import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from scipy import stats
from data import load, to_ppm, PROSPECTS

import glob
for f in glob.glob("/usr/share/texmf/fonts/opentype/public/tex-gyre/texgyretermes-*.otf"):
    fm.fontManager.addfont(f)  # TeX Gyre Termes if available
plt.rcParams.update({"font.family": "TeX Gyre Termes", "font.size": 8, "axes.linewidth": 0.6,
                     "axes.edgecolor": "#52514e", "xtick.color": "#52514e", "ytick.color": "#52514e",
                     "axes.labelcolor": "#0b0b0b", "xtick.major.width": 0.5, "ytick.major.width": 0.5,
                     "xtick.major.size": 2.5, "ytick.major.size": 2.5, "legend.frameon": False,
                     "axes.spines.top": False, "axes.spines.right": False, "mathtext.fontset": "stix",
                     "savefig.dpi": 600, "pdf.fonttype": 42})
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
GREY, INK2, GRID = "#8a8985", "#52514e", "#e6e5e1"
OUT = "figures/"
import os
os.makedirs(OUT, exist_ok=True)

df = load()
X = to_ppm(df)
r = json.load(open("results/p1_results.json"))
P = np.load("results/p1_pca.npy", allow_pickle=True).item()
k3 = P["k3"]
# cluster identity by content: Songwe As-rich group, Au-relative group, background
lab_name = {}
for c in np.unique(k3):
    ids = list(df.id[k3 == c])
    if "J0908" in ids:
        lab_name[c] = ("G2  As-rich (Songwe)", ORANGE)
    elif "J0922" in ids:
        lab_name[c] = ("G3  Au-enriched (Tchamilungi, Katabwe, Kingombe)", BLUE)
    else:
        lab_name[c] = ("G1  Au-poor, Zn-bearing", AQUA)
mcd_flag = P["d2"] > P["cut"]

# ---------------------------------------------------------------- Figure 1
fig, ax = plt.subplots(1, 3, figsize=(7.1, 2.55), gridspec_kw=dict(width_ratios=[1.15, 1, 1], wspace=0.45))
a = ax[0]
E, N = df.E / 1000, df.N / 1000
for p in PROSPECTS:
    s = (df.prospect == p).values
    mx = df.Au[s].max()
    sz = 25 + 60 * (np.log10(mx) + 2.2) / 3.6
    a.scatter(E[s].mean(), N[s].mean(), s=sz * 2.2, color="#b9b8b3", alpha=0.45, edgecolor=GREY, lw=0.7, zorder=3)
    a.scatter(E[s].mean(), N[s].mean(), s=4, color="#0b0b0b", zorder=4)
lab = {"Kingombe-Mbale": ("Kingombe-Mbale\nn = 3, max 0.19", (-0.45, -0.25), "right"),
       "Katabwe": ("Katabwe\n3, 0.16", (0.4, 0.05), "left"),
       "Songwe": ("Songwe\n5, 0.84", (-0.1, -1.05), "center"), "Kabolonde": ("Kabolonde\n4, 0.03", (0.45, -0.75), "left"),
       "Kikozi": ("Kikozi\n4, 0.02", (-0.35, 0.15), "right"), "Tchamilungi": ("Tchamilungi\n1, 21.8", (0.0, 0.6), "center")}
for p in PROSPECTS:
    s_ = (df.prospect == p).values
    t, (dx, dy), ha = lab[p]
    a.text(E[s_].mean() + dx, N[s_].mean() + dy, t, fontsize=6.2, color=INK2, ha=ha, va="bottom", linespacing=0.95)
a.set_xlim(413.9, 421.9)
a.set_ylim(9617.2, 9624.2)
a.set_aspect("equal")
a.set_xlabel("Easting (km, UTM 35S)")
a.set_ylabel("Northing (km)")
a.grid(color=GRID, lw=0.4)
a.set_axisbelow(True)
a.plot([414.3, 415.3], [9617.55, 9617.55], color="#0b0b0b", lw=1.2)
a.text(414.8, 9617.7, "1 km", ha="center", fontsize=6.5)
a.annotate("", xy=(421.4, 9624.0), xytext=(421.4, 9623.3), arrowprops=dict(arrowstyle="-|>", lw=0.6, color="#0b0b0b"))
a.text(421.15, 9623.55, "N", ha="right", va="center", fontsize=7)
a.set_title("(a) Prospects (n, max Au g/t)", fontsize=8, loc="left")
a.ticklabel_format(useOffset=False, style="plain")

# (b) Au vs Cu, linear axes
b = ax[1]
au, cu, as_ = df.Au.values, df.Cu.values, df.As.values
b.scatter(cu[:-1], au[:-1], s=16, color=GREY, alpha=0.7, edgecolor="white", lw=0.5, zorder=3)
b.scatter(cu[-1], au[-1], s=26, color=BLUE, edgecolor="white", lw=0.5, zorder=3)
xx = np.linspace(0, 380, 50)
p_all = np.polyfit(cu, au, 1)
p_wo = np.polyfit(cu[:-1], au[:-1], 1)
b.plot(xx, np.polyval(p_all, xx), color=BLUE, lw=1.2)
b.plot(xx, np.polyval(p_wo, xx), color=ORANGE, lw=1.2, ls="--")
b.text(40, 17.5, "all 20: $r$ = 0.84", color=BLUE, fontsize=7)
b.text(120, 1.6, "without J0922: $r$ = 0.01", color=ORANGE, fontsize=7)
b.annotate("J0922", (cu[-1], au[-1]), xytext=(-6, -10), textcoords="offset points", fontsize=6.5, ha="right", color=INK2)
b.set_xlabel("Cu (ppm)")
b.set_ylabel("Au (g/t)")
b.set_ylim(-1, 23.5)
b.set_xlim(-10, 390)
b.set_title("(b) Au–Cu, linear scale", fontsize=8, loc="left")
b.grid(color=GRID, lw=0.4)
b.set_axisbelow(True)

# (c) Au vs As, log-log
c = ax[2]
for cl in sorted(lab_name):
    s = k3 == cl
    c.scatter(as_[s], au[s], s=18, color=lab_name[cl][1], alpha=0.7, edgecolor="white", lw=0.5, zorder=3)
c.set_xscale("log")
c.set_yscale("log")
la, lx = np.log10(au), np.log10(as_)
pp = np.polyfit(lx, la, 1)
xg = np.linspace(lx.min(), lx.max(), 20)
c.plot(10 ** xg, 10 ** np.polyval(pp, xg), color=INK2, lw=0.9)
rs = [x for x in r["assoc"] if x["element"] == "As"][0]
c.text(14, 6, "$r_s$ = %.2f [%.2f, %.2f]" % (rs["rs"], rs["rs_ci"][0], rs["rs_ci"][1]), fontsize=7, color="#0b0b0b")
c.text(14, 2.6, "$\\rho_p$ = %.2f" % rs["rho_p"], fontsize=7, color="#0b0b0b")
c.set_xlabel("As (ppm)")
c.set_ylabel("Au (g/t)")
c.set_title("(c) Au–As, log scale", fontsize=8, loc="left")
hh=[plt.Line2D([], [], marker="o", ls="", color=lab_name[q][1], alpha=0.75, ms=4.5, label=lab_name[q][0].split("  ")[0]) for q in sorted(lab_name)]
c.legend(handles=hh, fontsize=6.3, loc="lower right", handletextpad=0.1, borderaxespad=0.1)
c.grid(color=GRID, lw=0.4, which="major")
c.set_axisbelow(True)
fig.savefig(OUT + "fig1_map_scatter.pdf", bbox_inches="tight")
fig.savefig(OUT + "fig1_map_scatter.png", bbox_inches="tight", dpi=300)
plt.close(fig)

# ---------------------------------------------------------------- Figure 2: association forest plot
fig, ax = plt.subplots(figsize=(3.45, 2.35))
els = ["As", "Cu", "Fe", "Zn"]
rows = []
for e in els:
    A = [x for x in r["assoc"] if x["element"] == e][0]
    rows.append((e, A))
ypos = 0
yt, yl = [], []
for e, A in rows:
    items = [("Pearson, raw", A["r_raw"], A["raw_boot_ci"], GREY, "s"),
             ("Spearman", A["rs"], A["rs_ci"], BLUE, "o"),
             ("Proportionality $\\rho_p$", A["rho_p"], A["rho_p_ci"], ORANGE, "D")]
    for j, (nm, v, ci, col, mk) in enumerate(items):
        y = ypos - j * 0.28
        ax.plot(ci, [y, y], color=col, lw=1.4, alpha=0.65, solid_capstyle="round")
        ax.plot(v, y, mk, color=col, ms=4.2, mec="white", mew=0.5)
    # raw Pearson without J0922
    ax.plot(A["r_raw_without_J0922"], ypos, "|", color="#0b0b0b", ms=7, mew=1.0)
    yt.append(ypos - 0.28)
    yl.append("Au–" + e)
    ypos -= 1.25
ax.axvline(0, color=INK2, lw=0.6)
ax.set_yticks(yt)
ax.set_yticklabels(yl)
ax.set_xlim(-0.85, 1.02)
ax.set_xlabel("Association coefficient (95% bootstrap interval)")
ax.grid(axis="x", color=GRID, lw=0.4)
ax.set_axisbelow(True)
h = [plt.Line2D([], [], marker="s", color=GREY, lw=1.4, ms=4, label="Pearson, raw"),
     plt.Line2D([], [], marker="|", color="#0b0b0b", ls="", ms=7, mew=1, label="Pearson, raw, without J0922"),
     plt.Line2D([], [], marker="o", color=BLUE, lw=1.4, ms=4, label="Spearman $r_s$"),
     plt.Line2D([], [], marker="D", color=ORANGE, lw=1.4, ms=3.5, label="Proportionality $\\rho_p$")]
ax.legend(handles=h, fontsize=6.3, loc="upper center", bbox_to_anchor=(0.5, 1.22), ncol=2, columnspacing=0.8,
          handlelength=1.6)
ax.spines["left"].set_visible(False)
ax.tick_params(axis="y", length=0)
fig.savefig(OUT + "fig2_association.pdf", bbox_inches="tight")
fig.savefig(OUT + "fig2_association.png", bbox_inches="tight", dpi=300)
plt.close(fig)

# ---------------------------------------------------------------- Figure 3: DD plot and clr biplot
fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.6), gridspec_kw=dict(wspace=0.32))
a = ax[0]
d2c = np.array([x["d2_classic"] for x in sorted(r["anomaly"], key=lambda z: z["id"])])
d2r = np.array([x["d2_mcd"] for x in sorted(r["anomaly"], key=lambda z: z["id"])])
ids = sorted(df.id)
order = np.argsort(df.id.values)
kk = k3[order]
dc, dr = np.sqrt(d2c), np.sqrt(d2r)
cut = np.sqrt(P["cut"])
for cl in sorted(lab_name):
    s = kk == cl
    a.scatter(dc[s], dr[s], s=20, color=lab_name[cl][1], alpha=0.75, edgecolor="white", lw=0.5, zorder=3)
a.axvline(cut, color=INK2, lw=0.6, ls="--")
a.axhline(cut, color=INK2, lw=0.6, ls="--")
simcut = np.sqrt(json.load(open("results/p1_review_checks.json"))["mcd_sim_q975_pointwise"])
a.axhline(simcut, color=ORANGE, lw=0.8, ls="-.")
a.text(3.97, simcut * 1.45, "simulated 97.5%% quantile\nfor $n=20$, $p=5$ (%.1f)" % simcut, fontsize=6.2, color=ORANGE, ha="right", va="bottom")
a.text(1.0, cut * 1.06, "$\\chi^2_{5;\\,0.975}$ cut-off (3.58)", fontsize=6.2, color=INK2)
a.set_yscale("log")
for i, nm in enumerate(ids):
    if dr[i] > cut or dc[i] > 3.2:
        a.annotate(nm, (dc[i], dr[i]), xytext=(3, 2), textcoords="offset points", fontsize=6, color=INK2)
from matplotlib.ticker import FixedLocator, FixedFormatter, NullLocator
a.yaxis.set_major_locator(FixedLocator([1.5, 2, 3, 5, 10, 20]))
a.yaxis.set_major_formatter(FixedFormatter(["1.5", "2", "3", "5", "10", "20"]))
a.yaxis.set_minor_locator(NullLocator())
a.set_ylim(1.4, 60)
a.annotate("", xy=(3.75, simcut * 1.02), xytext=(3.75, simcut * 1.42), arrowprops=dict(arrowstyle="-", lw=0.5, color=ORANGE))
a.set_xlabel("Classical Mahalanobis distance (ilr)")
a.set_ylabel("Robust (MCD) distance, log scale")
a.set_title("(a) Distance–distance plot", fontsize=8, loc="left")
a.grid(color=GRID, lw=0.4)
a.set_axisbelow(True)
a.set_xlim(0.9, 4.0)

b = ax[1]
U, s, Vt = P["U"], P["s"], P["Vt"]
sc = U[:, :2] * s[:2]
for cl in sorted(lab_name):
    m_ = k3 == cl
    b.scatter(sc[m_, 0], sc[m_, 1], s=20, color=lab_name[cl][1], alpha=0.75, edgecolor="white", lw=0.5, zorder=3,
              label=lab_name[cl][0])
scale = 2.6 / np.abs(Vt[:2]).max()
for j, nm in enumerate(["Au", "As", "Fe", "Cu", "Zn"]):
    b.annotate("", xy=(Vt[0, j] * scale, Vt[1, j] * scale), xytext=(0, 0),
               arrowprops=dict(arrowstyle="-|>", lw=0.7, color=INK2, shrinkA=0, shrinkB=0))
    b.text(Vt[0, j] * scale * 1.12, Vt[1, j] * scale * 1.12, nm, fontsize=7.5, ha="center", va="center", color="#0b0b0b")
for i in range(len(df)):
    if df.id[i] in ("J0922", "J0912"):
        b.annotate(df.id[i], sc[i], xytext=(-4, 3), textcoords="offset points", fontsize=6, color=INK2, ha="right")
pv = np.array(r["pca_var"]) * 100
b.set_xlabel("clr-PC1 (%.0f%%)" % pv[0])
b.set_ylabel("clr-PC2 (%.0f%%)" % pv[1])
b.axhline(0, color=GRID, lw=0.6)
b.axvline(0, color=GRID, lw=0.6)
b.set_title("(b) clr biplot, Ward groups", fontsize=8, loc="left")
b.set_xlim(-4.0, 3.8)
b.set_ylim(-3.0, 3.0)
a.legend(*b.get_legend_handles_labels(), fontsize=6, loc="upper left", bbox_to_anchor=(0.0, 1.0), handletextpad=0.1, borderaxespad=0.1)
fig.savefig(OUT + "fig3_dd_biplot.pdf", bbox_inches="tight")
fig.savefig(OUT + "fig3_dd_biplot.png", bbox_inches="tight", dpi=300)
plt.close(fig)
print("ok", lab_name)
