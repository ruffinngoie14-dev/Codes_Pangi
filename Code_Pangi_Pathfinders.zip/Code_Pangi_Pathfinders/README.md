# Code – "One Sample Is Not a Pathfinder" (A2MRA 2027)

Data: 20 rock-chip assays from permit PR3280 (Pangi, Maniema, DR Congo) in `data.py`
(Au g/t; As, Cu, Zn ppm; Fe wt%; UTM 35S). J0920 and J0921 of the field report are not available.

Run in this order (Python 3.11+, `pip install -r requirements.txt`):

1. `python p1_analysis.py` – Pearson, Spearman, Kendall, proportionality; bootstrap, jackknife,
   Holm; Cook's distance; median+2MAD threshold; ilr/clr; classical and MCD distances;
   isolation forest; LOF; ensemble score; Ward clustering, silhouette, bootstrap Jaccard.
   Writes `results/p1_results.json`, `results/p1_pca.npy`.
2. `python p1_review_checks.py` – simulated small-sample cut-off for MCD (2,000 simulations,
   env. variable `NSIM`), prospect-level checks (medians, cluster bootstrap, within-prospect
   permutation), detection-limit substitution. Writes `results/p1_review_checks.json`.
3. `python figs_p1.py` – Figures 1–3 (PDF, PNG) in `figures/`.

Seed 20261028.
