"""Paper 2, AI module: Gaussian-process surrogate of log10 Au and Bayesian active learning
(preposterior analysis) to choose where the next samples reduce most the uncertainty on which
prospect ranks first under the replication-weighted MMCM."""
import json
import math
import numpy as np
from scipy import optimize, stats
from scipy.spatial.distance import cdist

src = open("p2_analysis.py").read().split("# ------------------------------------------------------------------ SMAA")[0]
src = src.replace("for _ in range(20000):", "for _ in range(0):")
exec(src)
rng = np.random.default_rng(20261028)

S = df[["E", "N"]].values / 1000.0          # km
y = np.log10(df.Au.values)
C = np.array([S[df.prospect.values == p].mean(0) for p in PROSPECTS])
M_VAR = 10.0                                # vague prior on the constant mean (integrated out)


def matern32(A, B, ell):
    d = cdist(A, B) / ell
    return (1 + math.sqrt(3) * d) * np.exp(-math.sqrt(3) * d)


def kern(A, B, th):
    sf2, ell = th[0], th[1]
    return M_VAR + sf2 * matern32(A, B, ell)


def nlml(logth):
    sf2, ell, sn2 = np.exp(logth)
    Kxx = kern(S, S, (sf2, ell)) + sn2 * np.eye(len(y))
    try:
        L = np.linalg.cholesky(Kxx)
    except np.linalg.LinAlgError:
        return 1e10
    a = np.linalg.solve(L.T, np.linalg.solve(L, y))
    return 0.5 * y @ a + np.log(np.diag(L)).sum() + 0.5 * len(y) * math.log(2 * math.pi)


# The nugget (chip-scale variance) is fixed at the pooled within-prospect variance of log10 Au,
# estimated from replicate chips; with six clusters the likelihood cannot separate it from short-range
# spatial variance (unconstrained ML drives the range to its lower bound and interpolates every chip).
_, _, eb_info = eb_shrink(df)
SN2 = eb_info["s2"]
best = None
for s0 in [(0.5, 0.5), (1.0, 2.0), (2.0, 5.0), (0.3, 0.3)]:
    r = optimize.minimize(lambda z: nlml(np.array([z[0], z[1], math.log(SN2)])), np.log(s0), method="L-BFGS-B",
                          bounds=[(math.log(1e-3), math.log(50)), (math.log(0.2), math.log(20))])
    if best is None or r.fun < best.fun:
        best = r
SF2, ELL = np.exp(best.x)
res = {"gp_hyper": dict(sf2=SF2, ell_km=ELL, sn2_fixed=SN2, nlml=best.fun)}
prof = []
for ell in [0.2, 0.5, 1, 2, 3, 5, 10]:
    r = optimize.minimize(lambda z: nlml(np.array([z[0], math.log(ell), math.log(SN2)])), [0.0], method="L-BFGS-B")
    prof.append((ell, round(-r.fun, 3), round(float(np.exp(r.x[0])), 3)))
res["profile_loglik_ell"] = prof
# unconstrained fit, reported for transparency
r_u = optimize.minimize(nlml, np.log([1.0, 1.0, 0.3]), method="L-BFGS-B",
                        bounds=[(math.log(1e-3), math.log(50)), (math.log(0.05), math.log(20)), (math.log(1e-3), math.log(10))])
res["unconstrained_fit"] = dict(zip(["sf2", "ell_km", "sn2"], np.exp(r_u.x).round(3).tolist()))


def posterior(Sobs, yobs, Snew, th):
    sf2, ell, sn2 = th
    Kxx = kern(Sobs, Sobs, (sf2, ell)) + sn2 * np.eye(len(yobs))
    Ksx = kern(Snew, Sobs, (sf2, ell))
    Kss = kern(Snew, Snew, (sf2, ell))
    L = np.linalg.cholesky(Kxx)
    a = np.linalg.solve(L.T, np.linalg.solve(L, yobs))
    v = np.linalg.solve(L, Ksx.T)
    mu = Ksx @ a
    cov = Kss - v.T @ v
    return mu, 0.5 * (cov + cov.T)


TH = (SF2, ELL, SN2)
mu0, cov0 = posterior(S, y, C, TH)
res["gp_post_mean_gt"] = dict(zip(PROSPECTS, np.round(10 ** mu0, 3).tolist()))
res["gp_post_sd"] = dict(zip(PROSPECTS, np.round(np.sqrt(np.diag(cov0)), 3).tolist()))
post_eb, psd_eb, _ = eb_shrink(df)
res["eb_post_mean_gt"] = dict(zip(PROSPECTS, np.round(10 ** post_eb, 3).tolist()))

# leave-one-prospect-out predictive check of the GP (log scale)
lopo = []
for j, p in enumerate(PROSPECTS):
    tr = df.prospect.values != p
    mu_j, cov_j = posterior(S[tr], y[tr], S[~tr], TH)
    sd = np.sqrt(np.diag(cov_j) + SN2)
    z = (y[~tr] - mu_j) / sd
    lopo.append(dict(prospect=p, mean_abs_err=float(np.mean(np.abs(y[~tr] - mu_j))), mean_z=float(z.mean())))
res["lopo"] = lopo

# ------------------------------------------------------------------ decision model
Vbase, _ = criteria(df)          # C2, C4, C5 kept from data; C1, C3, C6 recomputed below
_cache = {}


def first_place(theta, sd, peak):
    """theta: (m,) latent log10 grades; sd: (m,) posterior SD; peak: (m,) max log10 Au observed."""
    V = Vbase.copy()
    V[0] = theta
    V[2] = -sd
    V[5] = peak
    G = grades(V)
    key = G.tobytes()
    if key not in _cache:
        rk = wmmcm_rank(G, C_ROC)[0]
        o = np.argsort(rk)
        _cache[key] = int(o[0] * m + o[1])          # ordered top-2 pair (diamond, RC)
    return _cache[key]


def first_dist(mu, cov, peak, L=400):
    sd = np.sqrt(np.diag(cov))
    draws = rng.multivariate_normal(mu, cov, size=L, method="cholesky")
    f = np.bincount([first_place(t, sd, peak) for t in draws], minlength=m * m) / L
    return f


def entropy(pv):
    q = pv[pv > 0]
    return float(-(q * np.log2(q)).sum())


peak0 = np.array([y[df.prospect.values == p].max() for p in PROSPECTS])
iT = PROSPECTS.index("Tchamilungi")
pi0 = first_dist(mu0, cov0, peak0, L=4000)
res["prior_pairs"] = {f"{PROSPECTS[k // m]}>{PROSPECTS[k % m]}": round(float(v), 3) for k, v in enumerate(pi0) if v > 0}
res["prior_entropy_bits"] = entropy(pi0)
res["prior_P_T_above_1gt"] = float(stats.norm.sf(0, mu0[iT], math.sqrt(cov0[iT, iT])))


def preposterior(j, nadd, outer=250, inner=300):
    """Expected entropy and expected max probability after adding nadd samples at prospect j."""
    off = rng.uniform(-0.02, 0.02, size=(nadd, 2))              # within 20 m of the prospect centre
    Snew = C[j] + off
    # joint predictive of new observations
    mu_n, cov_n = posterior(S, y, Snew, TH)
    cov_n = cov_n + SN2 * np.eye(nadd)
    Hs, Ps, pT = [], [], []
    for _ in range(outer):
        ynew = rng.multivariate_normal(mu_n, cov_n)
        S2, y2 = np.vstack([S, Snew]), np.concatenate([y, ynew])
        mu2, cov2 = posterior(S2, y2, C, TH)
        pk = peak0.copy()
        pk[j] = max(pk[j], ynew.max())
        f = first_dist(mu2, cov2, pk, L=inner)
        Hs.append(entropy(f))
        Ps.append(f.max())
        pT.append(stats.norm.sf(0, mu2[iT], math.sqrt(cov2[iT, iT])))
    pT = np.array(pT)
    hb = lambda q: 0.0 if q <= 0 or q >= 1 else float(-(q * np.log2(q) + (1 - q) * np.log2(1 - q)))
    return dict(exp_entropy=float(np.mean(Hs)), info_gain=res["prior_entropy_bits"] - float(np.mean(Hs)),
                exp_max_prob=float(np.mean(Ps)), exp_entropy_T1gt=float(np.mean([hb(q) for q in pT])),
                P_T1gt_q10_q90=[float(np.quantile(pT, .1)), float(np.quantile(pT, .9))])


act = {}
for nadd in (5, 10):
    for j, p in enumerate(PROSPECTS):
        act[f"{p}|{nadd}"] = preposterior(j, nadd)
        print(p, nadd, {k: (round(v, 3) if isinstance(v, float) else v) for k, v in act[f"{p}|{nadd}"].items()}, flush=True)
res["actions"] = act

# sensitivity of the design to the length scale
sens = {}
for ell in (0.5, 5.0):
    TH_s = (SF2, ell, SN2)
    mu_s, cov_s = posterior(S, y, C, TH_s)
    fd = first_dist(mu_s, cov_s, peak0, L=3000)
    sens[ell] = dict(pairs={f"{PROSPECTS[k // m]}>{PROSPECTS[k % m]}": round(float(v), 3) for k, v in enumerate(fd) if v > 0},
                     entropy=entropy(fd), P_T_above_1gt=float(stats.norm.sf(0, mu_s[iT], math.sqrt(cov_s[iT, iT]))))
res["ell_sensitivity"] = sens
# hyperparameters estimated without Tchamilungi (its chip inflates the spatial variance)
keepT = df.prospect.values != "Tchamilungi"
def nlml_sub(z):
    sf2, ell = np.exp(z)
    Kxx = kern(S[keepT], S[keepT], (sf2, ell)) + SN2 * np.eye(keepT.sum())
    L_ = np.linalg.cholesky(Kxx)
    a_ = np.linalg.solve(L_.T, np.linalg.solve(L_, y[keepT]))
    return 0.5 * y[keepT] @ a_ + np.log(np.diag(L_)).sum()
rs = optimize.minimize(nlml_sub, np.log([0.5, 1.0]), method="L-BFGS-B", bounds=[(math.log(1e-3), math.log(50)), (math.log(0.2), math.log(20))])
TH_w = (float(np.exp(rs.x[0])), float(np.exp(rs.x[1])), SN2)
mu_w, cov_w = posterior(S, y, C, TH_w)
fd = first_dist(mu_w, cov_w, peak0, L=3000)
res["hyper_without_T"] = dict(sf2=TH_w[0], ell_km=TH_w[1], post_mean_T_gt=float(10 ** mu_w[iT]), post_sd_T=float(math.sqrt(cov_w[iT, iT])),
                              P_T_above_1gt=float(stats.norm.sf(0, mu_w[iT], math.sqrt(cov_w[iT, iT]))),
                              pairs={f"{PROSPECTS[k // m]}>{PROSPECTS[k % m]}": round(float(v), 3) for k, v in enumerate(fd) if v > 0})
json.dump(res, open("results/p2_active_learning.json", "w"), indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))
print(json.dumps({k: res[k] for k in ["gp_hyper", "profile_loglik_ell", "gp_post_mean_gt", "gp_post_sd", "eb_post_mean_gt",
                                      "hyper_without_T", "prior_pairs", "prior_entropy_bits", "prior_P_T_above_1gt", "unconstrained_fit", "lopo", "ell_sensitivity"]}, indent=1, default=str))
