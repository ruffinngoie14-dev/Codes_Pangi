"""Paper 2: ranking the six PR3280 prospects with a replication-weighted Mean-Median Compromise
Method (MMCM), empirical-Bayes grade shrinkage, an unsupervised anomaly criterion and
SMAA-type uncertainty analysis over weights and data."""
import json
import math
from fractions import Fraction
import numpy as np
import pandas as pd
from scipy import stats
from data import load, PROSPECTS

SEED = 20261028
rng = np.random.default_rng(SEED)
df = load()
P1 = np.load("results/p1_pca.npy", allow_pickle=True).item()
df["ens"] = P1["ens"]
m = len(PROSPECTS)


# ------------------------------------------------------------------ MMCM (Ngoie et al. 2024; correction 2026)
def nu(n):
    return int(math.floor(math.log2(n))) + 1


def ranks_k(n, k):
    out = []
    for p in range(1, 2 ** k):
        r = -(-n * p // 2 ** k)
        if r not in out:
            out.append(r)
    return out


def mmcm_score(g, k):
    g = np.sort(np.asarray(g, float))[::-1]
    return float(np.mean([g[r - 1] for r in ranks_k(len(g), k)]))


def mmcm_profile(g, k0=2):
    return tuple(mmcm_score(g, k) for k in range(k0, max(nu(len(g)), k0) + 1))


# ------------------------------------------------------------------ replication-weighted MMCM
def int_weights(w, den=None):
    """Reduced integer replication counts c with c/sum(c) = w (exact for rational w, else 1/1000 grid)."""
    if den is None:
        fr = [Fraction(x).limit_denominator(1000) for x in w]
    else:
        fr = [Fraction(int(round(x * den)), den) for x in w]
    L = math.lcm(*[f.denominator for f in fr])
    c = np.array([int(f * L) for f in fr])
    g = math.gcd(*c.tolist())
    return c // g


def wmmcm_profile(g, c, k0=2):
    return mmcm_profile(np.repeat(np.asarray(g, float), c), k0)


def wmmcm_rank(G, c):
    prof = [wmmcm_profile(G[:, j], c) for j in range(G.shape[1])]
    order = sorted(range(G.shape[1]), key=lambda j: prof[j], reverse=True)
    rk = np.empty(G.shape[1], int)
    rk[order] = np.arange(1, G.shape[1] + 1)
    return rk, prof


# checks: published worked example; k=1 weighted median, k=nu(N) weighted mean, monotonicity
assert abs(mmcm_score([5, 5, 4, 4, 3, 2], 2) - 4) < 1e-12 and abs(mmcm_score([5, 5, 4, 4, 3, 2], 3) - 23 / 6) < 1e-12
viol = 0
for _ in range(20000):
    mm = rng.integers(3, 8)
    g = rng.integers(1, 7, mm).astype(float)
    c = rng.integers(1, 10, mm)
    N = c.sum()
    e = np.repeat(g, c)
    assert abs(mmcm_score(e, nu(N)) - np.dot(g, c) / N) < 1e-9
    i = rng.integers(mm)
    g2 = g.copy()
    g2[i] += rng.integers(1, 3)
    for k in range(1, nu(N) + 1):
        if mmcm_score(np.repeat(g2, c), k) < mmcm_score(e, k) - 1e-12:
            viol += 1
MONO_VIOL = viol


# ------------------------------------------------------------------ criteria
def eb_shrink(d, exclude_for_tau=None):
    """Normal-normal empirical Bayes on log10 Au: pooled within-prospect variance, DerSimonian-Laird tau^2."""
    y = np.log10(d.Au.values)
    grp = d.prospect.values
    ys = {p: y[grp == p] for p in PROSPECTS}
    nj = np.array([len(ys[p]) for p in PROSPECTS])
    yb = np.array([ys[p].mean() for p in PROSPECTS])
    ss = sum(((ys[p] - ys[p].mean()) ** 2).sum() for p in PROSPECTS)
    s2 = ss / (len(y) - m)
    v = s2 / nj
    keep = np.ones(m, bool)
    if exclude_for_tau is not None:
        keep[PROSPECTS.index(exclude_for_tau)] = False
    wd = 1 / v[keep]
    ybk = yb[keep]
    Q = np.sum(wd * (ybk - np.average(ybk, weights=wd)) ** 2)
    tau2 = max(1e-6, (Q - (keep.sum() - 1)) / (wd.sum() - (wd ** 2).sum() / wd.sum()))
    mu = np.average(ybk, weights=1 / (v[keep] + tau2))
    B = v / (v + tau2)
    post = B * mu + (1 - B) * yb
    psd = np.sqrt(1 / (1 / v + 1 / tau2))
    return post, psd, dict(s2=s2, tau2=tau2, mu=mu, shrink=B, ybar=yb, n=nj, post_sd=psd)


FIELD = {"Tchamilungi": 3, "Songwe": 3, "Katabwe": 2, "Kingombe-Mbale": 1, "Kabolonde": 1, "Kikozi": 1}
CRIT = ["EB grade", "Anomaly score", "Support", "As signature", "Field evidence", "Peak Au"]
K = len(CRIT)
ROC = np.array([sum(1 / j for j in range(i, K + 1)) / K for i in range(1, K + 1)])
C_ROC = int_weights([Fraction(sum(Fraction(1, j) for j in range(i, K + 1)), K) for i in range(1, K + 1)])


def criteria(d, exclude_for_tau=None):
    post, psd, info = eb_shrink(d, exclude_for_tau)
    V = np.zeros((K, m))
    for j, p in enumerate(PROSPECTS):
        s = d[d.prospect == p]
        V[0, j] = post[j]
        V[1, j] = s.ens.mean()
        V[2, j] = -psd[j]                       # benefit form: smaller posterior SD is better
        V[3, j] = np.median(np.log10(s.As))
        V[4, j] = FIELD[p]
        V[5, j] = np.log10(s.Au.max())
    return V, info


def grades(V):
    return np.vstack([stats.rankdata(v) for v in V])  # 1 = worst ... 6 = best, ties averaged


def saw(V, w):
    return w @ ((V - V.min(1, keepdims=True)) / (np.ptp(V, 1, keepdims=True) + 1e-12))


def topsis(V, w):
    S = V - V.min(1, keepdims=True) + 1.0           # positive shift (log values are negative)
    N = S / np.linalg.norm(S, axis=1, keepdims=True) * w[:, None]
    dp = np.sqrt(((N - N.max(1, keepdims=True)) ** 2).sum(0))
    dm = np.sqrt(((N - N.min(1, keepdims=True)) ** 2).sum(0))
    return dm / (dp + dm)


def wmedian(G, c):
    return np.array([mmcm_score(np.repeat(G[:, j], c), 1) for j in range(G.shape[1])])


def copeland(G, w):
    s = np.zeros(m)
    for a in range(m):
        for b in range(m):
            if a != b:
                pa, pb = w[G[:, a] > G[:, b]].sum(), w[G[:, b] > G[:, a]].sum()
                s[a] += int(pa > pb) - int(pa < pb)
    return s


def to_rank(score):
    o = sorted(range(m), key=lambda j: -score[j])
    r = np.empty(m, int)
    r[o] = np.arange(1, m + 1)
    return r


def all_rules(V, w, c):
    G = grades(V)
    tb = 1e-6 * saw(V, w)   # tie-break for median and Copeland, reported in the text
    return {"MMCM": wmmcm_rank(G, c)[0], "Mean": to_rank(saw(V, w)), "Median": to_rank(wmedian(G, c) + tb),
            "TOPSIS": to_rank(topsis(V, w)), "Copeland": to_rank(copeland(G, w) + tb)}


res = {"roc": ROC.round(4).tolist(), "c_roc": C_ROC.tolist(), "N_roc": int(C_ROC.sum()), "nu_N": nu(int(C_ROC.sum())),
       "mono_violations": MONO_VIOL}
V, info = criteria(df)
G = grades(V)
res["criteria"] = pd.DataFrame(V.T, index=PROSPECTS, columns=CRIT).round(3).to_dict()
res["grades"] = pd.DataFrame(G.T, index=PROSPECTS, columns=CRIT).to_dict()
res["eb"] = {k: (np.round(v, 3).tolist() if hasattr(v, "tolist") else v) for k, v in info.items()}
_, info_lo = criteria(df, exclude_for_tau="Tchamilungi")
res["eb_tau_without_T"] = {k: (np.round(v, 3).tolist() if hasattr(v, "tolist") else v) for k, v in info_lo.items()}
rk, prof = wmmcm_rank(G, C_ROC)
res["mmcm_profile"] = {PROSPECTS[j]: [round(x, 3) for x in prof[j]] for j in range(m)}
res["unweighted_mmcm_profile"] = {PROSPECTS[j]: [round(x, 3) for x in mmcm_profile(G[:, j])] for j in range(m)}
base = all_rules(V, ROC, C_ROC)
rules = list(base)
res["base_ranks"] = {r: dict(zip(PROSPECTS, base[r].tolist())) for r in rules}
res["equal_ranks"] = {r: dict(zip(PROSPECTS, v.tolist())) for r, v in all_rules(V, np.ones(K) / K, np.ones(K, int)).items()}
keep = [i for i in range(K) if CRIT[i] != "Field evidence"]
w5 = np.array([sum(1 / j for j in range(i, K)) / (K - 1) for i in range(1, K)])
res["nofield_ranks"] = {r: dict(zip(PROSPECTS, v.tolist())) for r, v in all_rules(V[keep], w5, int_weights(w5)).items()}
keep2 = [i for i in range(K) if CRIT[i] != "Support"]
res["nosupport_ranks"] = {r: dict(zip(PROSPECTS, v.tolist())) for r, v in all_rules(V[keep2], w5, int_weights(w5)).items()}
Vlo, _ = criteria(df, exclude_for_tau="Tchamilungi")
res["tau_without_T_ranks"] = {r: dict(zip(PROSPECTS, v.tolist())) for r, v in all_rules(Vlo, ROC, C_ROC).items()}

# ------------------------------------------------------------------ SMAA-type uncertainty
groups = [np.where(df.prospect.values == p)[0] for p in PROSPECTS]
NS = 3000
SC = {"ordered weights": ("ord", False), "free weights": ("free", False), "data": (None, True),
      "ordered weights + data": ("ord", True)}
acc = {s: {r: np.zeros((m, m)) for r in rules} for s in SC}
pair = {s: {r: np.zeros((m, m)) for r in rules} for s in SC}   # P(row ranked above column)
for s, (wmode, boot) in SC.items():
    for it in range(NS):
        if wmode == "ord":
            w = np.sort(rng.dirichlet(np.ones(K)))[::-1]
        elif wmode == "free":
            w = rng.dirichlet(np.ones(K))
        else:
            w = ROC
        c = C_ROC if wmode is None else int_weights(w, den=200)
        c = np.maximum(c, 1) if wmode is None else c
        if boot:
            idx = np.concatenate([rng.choice(ix, len(ix), replace=True) for ix in groups])
            Vb, _ = criteria(df.iloc[idx].reset_index(drop=True))
        else:
            Vb = V
        if c.sum() == 0:
            continue
        w_eff = c / c.sum()
        R = all_rules(Vb, w_eff, c)
        for r in rules:
            acc[s][r][np.arange(m), R[r] - 1] += 1
            pair[s][r] += (R[r][:, None] < R[r][None, :])
res["acceptability"] = {s: {r: (acc[s][r] / NS).round(3).tolist() for r in rules} for s in SC}
res["pairwise"] = {s: {r: (pair[s][r] / NS).round(3).tolist() for r in rules} for s in SC}
ranks_mat = np.array([base[r] for r in rules])
res["kendall_between_rules"] = {f"{a}|{b}": round(stats.kendalltau(ranks_mat[i], ranks_mat[j])[0], 3)
                               for i, a in enumerate(rules) for j, b in enumerate(rules) if i < j}
json.dump(res, open("results/p2_results.json", "w"), indent=1,
          default=lambda o: o.item() if hasattr(o, "item") else str(o))
np.save("results/p2_acc.npy", dict(acc=acc, pair=pair, NS=NS, rules=rules, SC=list(SC)), allow_pickle=True)

print(pd.DataFrame(V.T, index=PROSPECTS, columns=CRIT).round(3))
print("EB", res["eb"]);print("EB tau w/o T", res["eb_tau_without_T"])
print("ROC", res["roc"], res["c_roc"], res["N_roc"], "nu", res["nu_N"], "mono viol", MONO_VIOL)
print(res["mmcm_profile"]);print(res["unweighted_mmcm_profile"])
for k in ["base_ranks", "equal_ranks", "nofield_ranks", "nosupport_ranks", "tau_without_T_ranks"]:
    print(k);print(pd.DataFrame(res[k]).T)
print(res["kendall_between_rules"])
for s in SC:
    print("==", s)
    for r in rules:
        a = acc[s][r] / NS
        print(f"  {r:9s} first:", dict(zip(PROSPECTS, a[:, 0].round(3))), " P(T>S)=%.3f P(S>Ka)=%.3f" %
              (pair[s][r][5, 2] / NS, pair[s][r][2, 1] / NS))
