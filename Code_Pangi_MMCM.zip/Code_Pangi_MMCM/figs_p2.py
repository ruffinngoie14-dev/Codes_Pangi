import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from PIL import Image

src = open("p2_analysis.py").read().split("# ------------------------------------------------------------------ SMAA")[0]
src = src.replace("for _ in range(20000):", "for _ in range(0):")
exec(src)
import glob
for f in glob.glob("/usr/share/texmf/fonts/opentype/public/tex-gyre/texgyretermes-*.otf"):
    fm.fontManager.addfont(f)  # TeX Gyre Termes if available
plt.rcParams.update({"font.family": "TeX Gyre Termes", "font.size": 8, "axes.linewidth": 0.6,
                     "axes.edgecolor": "#52514e", "xtick.color": "#52514e", "ytick.color": "#52514e",
                     "xtick.major.width": 0.5, "ytick.major.width": 0.5, "xtick.major.size": 2.5,
                     "ytick.major.size": 2.5, "legend.frameon": False, "axes.spines.top": False,
                     "axes.spines.right": False, "mathtext.fontset": "stix", "pdf.fonttype": 42})
BLUE, ORANGE, AQUA, YELLOW, MAG, GREEN = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300"
GREY, INK2, GRID = "#8a8985", "#52514e", "#e6e5e1"
OUT = "figures/"
import os
os.makedirs(OUT, exist_ok=True)
R2 = json.load(open("results/p2_results.json"))
A = np.load("results/p2_acc.npy", allow_pickle=True).item()
short = {"Kingombe-Mbale": "Kingombe", "Katabwe": "Katabwe", "Songwe": "Songwe", "Kabolonde": "Kabolonde",
         "Kikozi": "Kikozi", "Tchamilungi": "Tchamilungi"}

# ---------------------------------------------------------------- Figure 1: ASTER context + grade matrix
fig = plt.figure(figsize=(5.6, 2.1))
ax1 = fig.add_axes([0.33, 0.12, 0.66, 0.8])
order = [PROSPECTS.index(p) for p in ["Tchamilungi", "Songwe", "Katabwe", "Kingombe-Mbale", "Kabolonde", "Kikozi"]]
Gm = G[:, order]
Vm = V[:, order]
from matplotlib.colors import LinearSegmentedColormap
cmap = LinearSegmentedColormap.from_list("b", ["#f3f7fd", "#cde2fb", "#86b6ef", "#3987e5", "#1c5cab"])
ax1.imshow(Gm, cmap=cmap, vmin=1, vmax=6, aspect="auto")
fmt = ["%.2f", "%.2f", "%.2f", "%.2f", "%d", "%.2f"]
for i in range(K):
    for j in range(m):
        v = Vm[i, j]
        if CRIT[i] == "Support":
            t = "%.2f" % (-v)
        elif CRIT[i] == "Field evidence":
            t = "%d" % v
        elif CRIT[i] in ("EB grade", "Peak Au"):
            t = ("%.2f" % 10 ** v) if 10 ** v < 1 else ("%.1f" % 10 ** v)
        elif CRIT[i] == "As signature":
            t = "%d" % round(10 ** v)
        else:
            t = "%.2f" % v
        ax1.text(j, i, t, ha="center", va="center", fontsize=6.6, color="#0b0b0b" if Gm[i, j] < 5 else "white")
ax1.set_xticks(range(m))
ax1.set_xticklabels([short[PROSPECTS[o]] for o in order], fontsize=7)
lbl = ["EB grade (g/t)", "Anomaly score", "Posterior SD", "Median As (ppm)", "Field evidence", "Peak Au (g/t)"]
ax1.set_yticks(range(K))
ax1.set_yticklabels(["C%d  %s (w=%.3f)" % (i + 1, lbl[i], ROC[i]) for i in range(K)], fontsize=7)
ax1.tick_params(length=0)
for sp in ax1.spines.values():
    sp.set_visible(False)
ax1.set_xticks(np.arange(-0.5, m), minor=True)
ax1.set_yticks(np.arange(-0.5, K), minor=True)
ax1.grid(which="minor", color="white", lw=1.5)
ax1.tick_params(which="minor", length=0)

fig.savefig(OUT + "fig1_context_grades.pdf", bbox_inches="tight", dpi=600)
fig.savefig(OUT + "fig1_context_grades.png", bbox_inches="tight", dpi=300)
plt.close(fig)

# ---------------------------------------------------------------- Figure 2: compromise path + acceptability
fig, ax = plt.subplots(1, 2, figsize=(7.1, 2.5), gridspec_kw=dict(width_ratios=[1, 1.15], wspace=0.35))
a = ax[0]
Nn = int(C_ROC.sum())
ks = list(range(1, nu(Nn) + 1))
cols = {"Tchamilungi": BLUE, "Songwe": ORANGE, "Katabwe": AQUA, "Kingombe-Mbale": GREY, "Kabolonde": "#b9b8b3",
        "Kikozi": "#d4d3cf"}
for p in ["Tchamilungi", "Songwe", "Katabwe", "Kingombe-Mbale", "Kabolonde", "Kikozi"]:
    j = PROSPECTS.index(p)
    e = np.repeat(G[:, j], C_ROC)
    y = [mmcm_score(e, k) for k in ks]
    a.plot(ks, y, "-o", color=cols[p], lw=1.6 if p in ("Songwe", "Katabwe", "Tchamilungi") else 1.0, ms=3.4,
           mec="white", mew=0.4)
    a.text(ks[-1] + 0.25, y[-1], short[p], fontsize=6.6, va="center", color=INK2)
a.set_xticks(ks)
a.set_xticklabels(["1\nmedian"] + [str(k) for k in ks[1:-1]] + ["%d\nmean" % ks[-1]])
a.set_xlim(0.6, ks[-1] + 2.3)
a.set_xlabel("Degree $k$ of the weighted MMCM")
a.set_ylabel("Score (grade scale 1–6)")
a.axvline(2, color=GRID, lw=3, zorder=0)
a.text(2.1, 1.05, "default $k$ = 2", fontsize=6.4, color=INK2)
a.grid(axis="y", color=GRID, lw=0.4)
a.set_title("(a) From weighted median to weighted mean", fontsize=8, loc="left")

b = ax[1]
acc = A["acc"]["ordered weights + data"]["MMCM"] / A["NS"]
po = ["Tchamilungi", "Songwe", "Katabwe", "Kingombe-Mbale", "Kabolonde", "Kikozi"]
rc = [BLUE, ORANGE, AQUA, YELLOW, MAG, GREEN]
for i, p in enumerate(po):
    j = PROSPECTS.index(p)
    left = 0
    for rnk in range(m):
        v = acc[j, rnk]
        if v > 0:
            b.barh(i, v, left=left, color=rc[rnk], alpha=0.75, edgecolor="white", lw=1.0, height=0.66)
            if v >= 0.09:
                b.text(left + v / 2, i, "%.0f" % (100 * v), ha="center", va="center", fontsize=6.3, color="#0b0b0b")
            left += v
b.set_yticks(range(m))
b.set_yticklabels([short[p] for p in po])
b.invert_yaxis()
b.set_xlim(0, 1)
b.set_xlabel("Rank acceptability (share of 3,000 draws)", labelpad=1)
h = [plt.Rectangle((0, 0), 1, 1, color=rc[r], alpha=0.75, label="rank %d" % (r + 1)) for r in range(m)]
b.legend(handles=h, fontsize=6.2, ncol=6, loc="upper center", bbox_to_anchor=(0.42, -0.2), handlelength=0.9,
         columnspacing=0.6, handletextpad=0.3)
b.set_title("(b) Weighted MMCM, ordered weights + bootstrap", fontsize=8, loc="left")
b.spines["left"].set_visible(False)
b.tick_params(axis="y", length=0)
fig.savefig(OUT + "fig2_path_acceptability.pdf", bbox_inches="tight")
fig.savefig(OUT + "fig2_path_acceptability.png", bbox_inches="tight", dpi=300)
plt.close(fig)

print("ok")
