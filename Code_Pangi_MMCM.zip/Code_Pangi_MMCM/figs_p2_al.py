import json, math, glob
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from matplotlib.colors import LinearSegmentedColormap
src = open("p2_active_learning.py").read().split("# leave-one-prospect-out")[0]
exec(src)
for f in glob.glob("/usr/share/texmf/fonts/opentype/public/tex-gyre/texgyretermes-*.otf"):
    fm.fontManager.addfont(f)
plt.rcParams.update({"font.family": "TeX Gyre Termes", "font.size": 8, "axes.linewidth": 0.6, "axes.edgecolor": "#52514e",
                     "xtick.color": "#52514e", "ytick.color": "#52514e", "legend.frameon": False, "axes.spines.top": False,
                     "axes.spines.right": False, "mathtext.fontset": "stix", "pdf.fonttype": 42})
BLUE, ORANGE, INK2, GRID = "#2a78d6", "#eb6834", "#52514e", "#e6e5e1"
R = json.load(open("results/p2_active_learning.json"))
fig, ax = plt.subplots(1, 2, figsize=(7.1, 2.55), gridspec_kw=dict(width_ratios=[1.05, 1], wspace=0.55))
a = ax[0]
gx, gy = np.meshgrid(np.linspace(414.2, 421.8, 150), np.linspace(9617.6, 9624.0, 120))
G2 = np.column_stack([gx.ravel(), gy.ravel()])
Kxx = kern(S, S, TH[:2]) + TH[2] * np.eye(len(y))
mu = kern(G2, S, TH[:2]) @ np.linalg.solve(Kxx, y)
cmap = LinearSegmentedColormap.from_list("b", ["#f3f7fd", "#cde2fb", "#86b6ef", "#3987e5", "#1c5cab", "#0d366b"])
cs = a.contourf(gx, gy, mu.reshape(gx.shape), levels=np.arange(-2.0, 1.21, 0.4), cmap=cmap, extend="both")
a.scatter(S[:, 0], S[:, 1], s=7, color="#0b0b0b", zorder=3)
short = {"Kingombe-Mbale": "Kingombe", "Katabwe": "Katabwe", "Songwe": "Songwe", "Kabolonde": "Kabolonde", "Kikozi": "Kikozi", "Tchamilungi": "Tchamilungi"}
off = {"Kingombe-Mbale": (0.0, -0.55), "Katabwe": (0.55, 0.35), "Songwe": (-0.2, -0.6), "Kabolonde": (0.75, -0.5), "Kikozi": (-0.2, 0.35), "Tchamilungi": (0, 0.45)}
for j, p in enumerate(PROSPECTS):
    a.text(C[j, 0] + off[p][0], C[j, 1] + off[p][1], short[p], fontsize=6.5, ha="center", color="#0b0b0b")
a.set_aspect("equal")
a.set_xlabel("Easting (km, UTM 35S)")
a.set_ylabel("Northing (km)")
a.ticklabel_format(useOffset=False, style="plain")
cb = fig.colorbar(cs, ax=a, shrink=0.85, pad=0.02)
cb.set_label("log$_{10}$Au (g/t), posterior mean", fontsize=6.8)
cb.ax.tick_params(labelsize=6.5)
a.set_title("(a) Gaussian-process surrogate ($\\ell$ = %.1f km)" % ELL, fontsize=8, loc="left")
b = ax[1]
order = ["Songwe", "Katabwe", "Kingombe-Mbale", "Tchamilungi", "Kabolonde", "Kikozi"]
yy = np.arange(len(order))
ig = [max(0, R["actions"][f"{p}|5"]["info_gain"]) for p in order]
H0T = 0.238
igT = [max(0, H0T - R["actions"][f"{p}|5"]["exp_entropy_T1gt"]) for p in order]
b.barh(yy - 0.19, ig, height=0.36, color=BLUE, alpha=0.75, label="which two prospects to drill")
b.barh(yy + 0.19, igT, height=0.36, color=ORANGE, alpha=0.75, label="whether Tchamilungi exceeds 1 g/t")
for i in range(len(order)):
    if ig[i] > 0.01:
        b.text(ig[i] + 0.015, yy[i] - 0.19, "%.2f" % ig[i], va="center", fontsize=6.3, color=INK2)
    if igT[i] > 0.01:
        b.text(igT[i] + 0.015, yy[i] + 0.19, "%.2f" % igT[i], va="center", fontsize=6.3, color=INK2)
b.set_yticks(yy)
b.set_yticklabels([short[p] for p in order], fontsize=7)
b.invert_yaxis()
b.set_xlabel("Expected entropy reduction (bits), five new chips")
b.set_xlim(0, 1.1)
b.grid(axis="x", color=GRID, lw=0.4)
b.set_axisbelow(True)
b.legend(fontsize=6.4, loc="lower right")
b.spines["left"].set_visible(False)
b.tick_params(axis="y", length=0)
b.set_title("(b) Value of the next five samples", fontsize=8, loc="left")
fig.savefig("figures/fig3_active_learning.pdf", bbox_inches="tight")
fig.savefig("figures/fig3_active_learning.png", bbox_inches="tight", dpi=300)
print("ok")
