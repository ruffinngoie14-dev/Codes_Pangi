"""Rock-chip data, PR3280 (Pangi, Maniema, DR Congo). Source: Appendix 3 of the field report,
20 of the 22 analyses (J0920 and J0921 not available). WGS84 / UTM 35S.
Au in g/t (= ppm), As, Cu, Zn in ppm, Fe in wt%."""
import pandas as pd

ROWS = [
    ("J0901", "Kingombe-Mbale", 418662, 9618479, 0.193, 433, 6.26, 105, 125),
    ("J0902", "Kingombe-Mbale", 418661, 9618479, 0.095, 97, 2.21, 95, 29),
    ("J0903", "Kingombe-Mbale", 418669, 9618522, 0.015, 91, 11.25, 103, 307),
    ("J0904", "Katabwe", 416502, 9622425, 0.130, 19, 0.91, 1, 2),
    ("J0905", "Katabwe", 416500, 9622421, 0.056, 53, 4.61, 4, 4),
    ("J0906", "Katabwe", 416484, 9622421, 0.160, 18, 1.51, 25, 8),
    ("J0907", "Songwe", 414803, 9622487, 0.003, 13, 3.63, 11, 27),
    ("J0908", "Songwe", 415528, 9622300, 0.838, 824, 20.6, 21, 3),
    ("J0909", "Songwe", 415534, 9622312, 0.189, 4280, 16.4, 172, 7),
    ("J0910", "Songwe", 415540, 9622306, 0.351, 1210, 10.85, 27, 3),
    ("J0911", "Songwe", 415548, 9622308, 0.053, 800, 9.25, 44, 3),
    ("J0912", "Kabolonde", 416680, 9622093, 0.010, 42, 10.95, 1, 4),
    ("J0913", "Kabolonde", 416855, 9622180, 0.015, 21, 7.47, 67, 56),
    ("J0914", "Kabolonde", 416855, 9622179, 0.021, 36, 10.2, 67, 58),
    ("J0915", "Kabolonde", 416855, 9622178, 0.026, 29, 8.65, 64, 43),
    ("J0916", "Kikozi", 415813, 9623022, 0.011, 104, 11.5, 14, 87),
    ("J0917", "Kikozi", 415812, 9623024, 0.007, 28, 2.55, 7, 16),
    ("J0918", "Kikozi", 415800, 9623026, 0.013, 79, 9.24, 29, 65),
    ("J0919", "Kikozi", 415801, 9623021, 0.021, 40, 5.35, 9, 40),
    ("J0922", "Tchamilungi", 420963, 9620234, 21.8, 4170, 16.2, 359, 180),
]
COLS = ["id", "prospect", "E", "N", "Au", "As", "Fe", "Cu", "Zn"]
PROSPECTS = ["Kingombe-Mbale", "Katabwe", "Songwe", "Kabolonde", "Kikozi", "Tchamilungi"]


def load():
    return pd.DataFrame(ROWS, columns=COLS)


def to_ppm(df):
    """All five parts in mg/kg, plus the residual R = 1e6 - sum (closure to 10^6)."""
    X = pd.DataFrame({"Au": df.Au, "As": df.As, "Fe": df.Fe * 1e4, "Cu": df.Cu, "Zn": df.Zn})
    X["R"] = 1e6 - X.sum(axis=1)
    return X
