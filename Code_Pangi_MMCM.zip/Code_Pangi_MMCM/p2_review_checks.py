"""Internal-review checks for Paper 2:
(1) ordinal vs cardinal grades for the MMCM (separate the effect of the rule from that of the scale);
(2) uncertainty of the single Tchamilungi chip: posterior-predictive redraws of its Au value;
(3) dropping the peak-Au criterion (double counting of Au)."""
import json
import numpy as np
src = open("p2_analysis.py").read().split("# ------------------------------------------------------------------ SMAA")[0]
src = src.replace("for _ in range(20000):", "for _ in range(0):")
exec(src)
rng = np.random.default_rng(7)
out = {}

# (1) cardinal grades: min-max normalised values mapped to [1, 6]
Gc = 1 + 5 * (V - V.min(1, keepdims=True)) / np.ptp(V, 1, keepdims=True)
rk_c, prof_c = wmmcm_rank(Gc, C_ROC)
out["mmcm_cardinal_ranks"] = dict(zip(PROSPECTS, rk_c.tolist()))
out["wmedian_cardinal"] = dict(zip(PROSPECTS, np.round(wmedian(Gc, C_ROC), 3).tolist()))
out["mmcm_cardinal_k2"] = {PROSPECTS[j]: round(prof_c[j][0], 3) for j in range(m)}
out["saw_ordinal_grades"] = dict(zip(PROSPECTS, to_rank(ROC @ G).tolist()))

# (2) Tchamilungi posterior-predictive: redraw its log10 Au from N(post mean, post sd^2 + sigma^2)
iT = PROSPECTS.index("Tchamilungi")
res2 = {}
for label, excl in [("tau2_all", None), ("tau2_without_T", "Tchamilungi")]:
    post, psd, info = eb_shrink(df, excl)
    mu_T, sd_T = post[iT], np.sqrt(psd[iT] ** 2 + info["s2"])
    first = {r: 0 for r in ["MMCM", "Mean", "Median", "TOPSIS", "Copeland"]}
    rankT = []
    NS = 2000
    for s in range(NS):
        d = df.copy()
        d.loc[d.prospect == "Tchamilungi", "Au"] = 10 ** rng.normal(mu_T, sd_T)
        w = np.sort(rng.dirichlet(np.ones(K)))[::-1]
        c = int_weights(w, den=200)
        Vb, _ = criteria(d, excl)
        R = all_rules(Vb, c / c.sum(), c)
        for r in first:
            first[r] += R[r][iT] == 1
        rankT.append(R["MMCM"][iT])
    res2[label] = dict(mu_T_gt=round(10 ** mu_T, 3), sd_T_log=round(sd_T, 3),
                       first={r: round(v / NS, 3) for r, v in first.items()},
                       mmcm_rank_dist={int(k): round(float(np.mean(np.array(rankT) == k)), 3) for k in range(1, 7)})
out["tchamilungi_predictive"] = res2

# (3) without peak Au (C6)
keep = [0, 1, 2, 3, 4]
w5 = np.array([sum(1 / j for j in range(i, 6)) / 5 for i in range(1, 6)])
out["no_peak_ranks"] = {r: dict(zip(PROSPECTS, v.tolist())) for r, v in all_rules(V[keep], w5, int_weights(w5)).items()}
json.dump(out, open("results/p2_review_checks.json", "w"), indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))
print(json.dumps(out, indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o)))
