# Code – "Ranking Gold Prospects on Sparse Evidence" (A2MRA 2027)

Data: 20 rock-chip assays from permit PR3280 (Pangi, Maniema, DR Congo) in `data.py`.

Run in this order (Python 3.11+, `pip install -r requirements.txt`):

1. `python p1_analysis.py` – per-sample unsupervised anomaly score (MCD in ilr coordinates,
   isolation forest, LOF) used as criterion C2. Writes `results/p1_pca.npy`.
2. `python p2_analysis.py` – MMCM (Ngoie et al. 2024; correction 2026) and its
   replication-weighted version with unit checks; empirical-Bayes grades; six criteria; ROC
   weights; five aggregation rules; sensitivity variants; SMAA (3,000 draws per scenario).
3. `python p2_review_checks.py` – cardinal vs ordinal grades, removal of peak Au, predictive
   redraw of the single Tchamilungi assay.
4. `python p2_active_learning.py` – Gaussian-process surrogate (Matérn-3/2, nugget fixed at the
   within-prospect variance, ML range and variance), leave-one-prospect-out check, and Bayesian
   active learning: expected entropy reduction of the drilling pair and of the Tchamilungi
   go/no-go question for 5 or 10 new chips per prospect (250 x 300 Monte Carlo; ~6 min).
5. `python p2_al_sensitivity.py` – same design with the range fixed at 0.5 and 5 km.
6. `python figs_p2.py` and `python figs_p2_al.py` – Figures 1–3 in `figures/`.

Seeds 20261028 (review checks: 7).
