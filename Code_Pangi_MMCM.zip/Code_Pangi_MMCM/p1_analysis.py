"""Paper 1: robustness of gold-pathfinder associations, compositional anomaly detection and
unsupervised grouping of the 20 PR3280 rock chips. Seed fixed for reproducibility."""
import json
import numpy as np
import pandas as pd
from scipy import stats
from scipy.cluster.hierarchy import linkage, fcluster
from sklearn.covariance import MinCovDet
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.metrics import silhouette_score
from data import load, to_ppm

SEED = 20261028
rng = np.random.default_rng(SEED)
df = load()
X = to_ppm(df)
n = len(df)
L = np.log(X[["Au", "As", "Fe", "Cu", "Zn"]].values)
names = ["Au", "As", "Fe", "Cu", "Zn"]
res = {}


def clr(M):
    lM = np.log(M)
    return lM - lM.mean(axis=1, keepdims=True)


def ilr(M):
    """Pivot (ilr) coordinates, D parts -> D-1 coordinates."""
    lM = np.log(M)
    D = lM.shape[1]
    Z = np.zeros((lM.shape[0], D - 1))
    for i in range(D - 1):
        Z[:, i] = np.sqrt((D - i - 1) / (D - i)) * (lM[:, i] - lM[:, i + 1:].mean(axis=1))
    return Z


def rho_p(a, b):
    """Proportionality coefficient (log scale): 1 - var(ln a/b)/(var ln a + var ln b)."""
    la, lb = np.log(a), np.log(b)
    return 1 - np.var(la - lb, ddof=1) / (np.var(la, ddof=1) + np.var(lb, ddof=1))


# ---------------------------------------------------------------- 1. pairwise associations
B = 10000
idx_boot = rng.integers(0, n, size=(B, n))
assoc = []
au = X.Au.values
for e in ["As", "Cu", "Fe", "Zn"]:
    x = X[e].values
    r_raw = stats.pearsonr(au, x)[0]
    r_raw_wo = stats.pearsonr(au[:-1], x[:-1])[0]
    r_log = stats.pearsonr(np.log(au), np.log(x))[0]
    rs, ps = stats.spearmanr(au, x)
    tau, pt = stats.kendalltau(au, x)
    # jackknife: drop each sample
    jk_raw = [stats.pearsonr(np.delete(au, i), np.delete(x, i))[0] for i in range(n)]
    jk_s = [stats.spearmanr(np.delete(au, i), np.delete(x, i))[0] for i in range(n)]
    bs = []
    bp = []
    braw = []
    for ib in idx_boot:
        a, b = au[ib], x[ib]
        if np.ptp(a) == 0 or np.ptp(b) == 0:
            continue
        bs.append(stats.spearmanr(a, b)[0])
        bp.append(rho_p(a, b))
        braw.append(np.corrcoef(a, b)[0, 1])
    bs, bp, braw = map(np.array, (bs, bp, braw))
    rp = rho_p(au, x)
    assoc.append(dict(
        element=e, r_raw=r_raw, r_raw_without_J0922=r_raw_wo, r_log=r_log,
        jk_raw_min=min(jk_raw), jk_raw_max=max(jk_raw), jk_raw_argmin=df.id[int(np.argmin(jk_raw))],
        rs=rs, p_rs=ps, rs_ci=list(np.percentile(bs, [2.5, 97.5])), jk_rs_min=min(jk_s), jk_rs_max=max(jk_s),
        tau=tau, p_tau=pt, raw_boot_ci=list(np.percentile(braw, [2.5, 97.5])),
        var_logratio=float(np.var(np.log(au) - np.log(x), ddof=1)), rho_p=rp,
        rho_p_ci=list(np.percentile(bp, [2.5, 97.5]))))
res["assoc"] = assoc

# Holm adjustment of the four Spearman p-values
ps = np.array([a["p_rs"] for a in assoc])
order = np.argsort(ps)
holm = np.empty(4)
run = 0
for k, i in enumerate(order):
    run = max(run, min(1, (4 - k) * ps[i]))
    holm[i] = run
for a, h in zip(assoc, holm):
    a["p_rs_holm"] = h

# leverage / Cook's distance of J0922 in the raw Au ~ Cu and Au ~ As regressions
for e in ["Cu", "As"]:
    x = X[e].values
    Xd = np.column_stack([np.ones(n), x])
    H = Xd @ np.linalg.inv(Xd.T @ Xd) @ Xd.T
    beta = np.linalg.lstsq(Xd, au, rcond=None)[0]
    resid = au - Xd @ beta
    s2 = resid @ resid / (n - 2)
    h = np.diag(H)
    cook = resid ** 2 / (2 * s2) * h / (1 - h) ** 2
    res[f"cook_{e}"] = dict(h_J0922=h[-1], cook_J0922=cook[-1], cook_next=float(np.sort(cook)[-2]))

# Pearson r of all pairs, log scale, full and without J0922
res["corr_log"] = np.corrcoef(L.T).round(3).tolist()
res["corr_raw"] = np.corrcoef(X[names].values.T).round(3).tolist()

# variation matrix (Aitchison): var(ln xi/xj)
V = np.array([[np.var(L[:, i] - L[:, j], ddof=1) for j in range(5)] for i in range(5)])
res["variation"] = V.round(3).tolist()
res["rho_p_matrix"] = np.array([[rho_p(X[a].values, X[b].values) for b in names] for a in names]).round(3).tolist()

# ---------------------------------------------------------------- 2. univariate threshold for Au
la = np.log10(au)
med = np.median(la)
mad = stats.median_abs_deviation(la, scale="normal")
thr = 10 ** (med + 2 * mad)
q1, q3 = np.percentile(la, [25, 75])
thr_box = 10 ** (q3 + 1.5 * (q3 - q1))
bt = []
for ib in idx_boot[:5000]:
    v = la[ib]
    bt.append(10 ** (np.median(v) + 2 * stats.median_abs_deviation(v, scale="normal")))
res["threshold"] = dict(median_gt=10 ** med, mad_log10=mad, thr_med2mad=thr, ci=list(np.percentile(bt, [2.5, 97.5])),
                        n_above=int((au > thr).sum()), above=list(df.id[au > thr]), thr_tukey_log=thr_box,
                        n_above_015=int((au > 0.15).sum()), above_015=list(df.id[au > 0.15]))

# ---------------------------------------------------------------- 3. multivariate anomaly detection
M6 = X[["Au", "As", "Fe", "Cu", "Zn", "R"]].values
Z = ilr(M6)
C = clr(M6)
d2_runs = []
for s in range(50):
    mcd = MinCovDet(random_state=s).fit(Z)
    d2_runs.append(mcd.mahalanobis(Z))
d2 = np.median(np.array(d2_runs), axis=0)
cut = stats.chi2.ppf(0.975, Z.shape[1])
# classical Mahalanobis for comparison
mu, S = Z.mean(0), np.cov(Z.T)
d2c = np.einsum("ij,jk,ik->i", Z - mu, np.linalg.inv(S), Z - mu)
if_scores = np.zeros(n)
for s in range(50):
    iso = IsolationForest(n_estimators=500, random_state=s, contamination="auto").fit(C)
    if_scores += -iso.score_samples(C) / 50
lof = LocalOutlierFactor(n_neighbors=5).fit(C)
lof_s = -lof.negative_outlier_factor_
# ensemble: mean of within-method ranks rescaled to [0,1]
rk = lambda v: (stats.rankdata(v) - 1) / (n - 1)
ens = (rk(d2) + rk(if_scores) + rk(lof_s)) / 3
anom = pd.DataFrame(dict(id=df.id, prospect=df.prospect, Au=df.Au, d2_mcd=d2, d2_classic=d2c,
                         mcd_flag=d2 > cut, iforest=if_scores, lof=lof_s, ensemble=ens))
anom = anom.sort_values("ensemble", ascending=False)
res["anomaly"] = anom.round(4).to_dict(orient="records")
res["chi2_cut"] = cut
res["n_mcd_flag"] = int((d2 > cut).sum())
res["n_classic_flag"] = int((d2c > cut).sum())
res["rho_ens_logAu"] = stats.spearmanr(ens, la)[0]
res["rho_ens_logAs"] = stats.spearmanr(ens, np.log(X.As))[0]

# ---------------------------------------------------------------- 4. unsupervised grouping (clr of 5-part subcomposition)
C5 = clr(X[names].values)
Lk = linkage(C5, "ward")
sil = {}
for k in range(2, 6):
    lab = fcluster(Lk, k, "maxclust")
    sil[k] = silhouette_score(C5, lab)
res["silhouette"] = sil
kbest = max(sil, key=sil.get)
lab = fcluster(Lk, kbest, "maxclust")
res["k_best"] = kbest


# bootstrap stability (Hennig-type Jaccard)
def jaccard(a, b):
    a, b = set(a), set(b)
    return len(a & b) / len(a | b) if a | b else 0


def stability(k, Bc=1000):
    lab0 = fcluster(Lk, k, "maxclust")
    clusters0 = [np.where(lab0 == c)[0] for c in np.unique(lab0)]
    J = np.zeros((Bc, len(clusters0)))
    for b in range(Bc):
        ib = np.unique(rng.integers(0, n, n))
        if len(ib) <= k:
            continue
        labb = fcluster(linkage(C5[ib], "ward"), k, "maxclust")
        cb = [ib[labb == c] for c in np.unique(labb)]
        for j, c0 in enumerate(clusters0):
            c0b = [i for i in c0 if i in ib]
            if not c0b:
                J[b, j] = np.nan
                continue
            J[b, j] = max(jaccard(c0b, c) for c in cb)
    return [list(map(lambda c: list(df.id[c]), clusters0)), np.nanmean(J, axis=0).round(3).tolist()]


res["stability"] = {k: stability(k) for k in (2, 3, 4)}
for k in (2, 3, 4):
    res[f"labels_k{k}"] = fcluster(Lk, k, "maxclust").tolist()
# cluster centroids (clr) for k=3
k3 = fcluster(Lk, 3, "maxclust")
res["centroids_k3"] = {int(c): dict(zip(names, C5[k3 == c].mean(0).round(2))) for c in np.unique(k3)}

# clr-PCA
Cc = C5 - C5.mean(0)
U, s, Vt = np.linalg.svd(Cc, full_matrices=False)
res["pca_var"] = (s ** 2 / (s ** 2).sum()).round(3).tolist()
res["pca_loadings"] = Vt[:2].round(3).tolist()
np.save("results/p1_pca.npy", dict(U=U, s=s, Vt=Vt, k3=k3, ens=ens, d2=d2, cut=cut, C5=C5), allow_pickle=True)

with open("results/p1_results.json", "w") as f:
    json.dump(res, f, indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))
print(json.dumps({k: res[k] for k in ["assoc", "threshold", "cook_Cu", "cook_As", "n_mcd_flag", "n_classic_flag",
                                     "silhouette", "stability", "centroids_k3", "pca_var", "rho_ens_logAu", "rho_ens_logAs"]},
                 indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o)))
print(anom.round(3).to_string())
print(np.array(res["variation"]))
print(np.array(res["rho_p_matrix"]))
