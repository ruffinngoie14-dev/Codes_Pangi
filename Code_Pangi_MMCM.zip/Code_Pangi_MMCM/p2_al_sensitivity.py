"""Sensitivity of the active-learning ranking of actions to the Gaussian-process range."""
import json
src = open("p2_active_learning.py").read().split("act = {}")[0]
exec(src)
out = {}
for ell in (0.5, 5.0):
    TH = (SF2, ell, SN2)
    mu0, cov0 = posterior(S, y, C, TH)
    pi0 = first_dist(mu0, cov0, peak0, L=4000)
    res["prior_entropy_bits"] = entropy(pi0)
    out[ell] = {"prior_entropy": entropy(pi0)}
    for j, p in enumerate(PROSPECTS):
        r = preposterior(j, 5, outer=150, inner=250)
        out[ell][p] = round(r["info_gain"], 3)
    print(ell, out[ell], flush=True)
json.dump(out, open("results/p2_al_sensitivity.json", "w"), indent=1)
